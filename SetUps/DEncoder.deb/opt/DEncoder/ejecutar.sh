#!/bin/bash

#Lanzamos la aplicacion
java -jar /opt/DEncoder/PI_DEncoder_BravoJose.jar
